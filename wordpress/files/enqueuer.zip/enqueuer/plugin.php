<?php
/*
Plugin Name:	Enqueuer
Description:	Enqueues Scripts and CSS files
*/

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'wp_enqueue_scripts', 'enqueue_files' );

function enqueue_files() {

}
